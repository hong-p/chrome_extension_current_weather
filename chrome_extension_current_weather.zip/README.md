# chrome_extension_current_weather

## 네이버 날씨 검색 기반으로 만든 확장프로그램

설치 URL
https://chrome.google.com/webstore/detail/current-weather/kjoemjpifgmkjoanmiejcegkoakkpbdi?utm_source=gmail
